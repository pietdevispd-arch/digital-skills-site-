document.addEventListener('DOMContentLoaded', function () {
  var toggle = document.querySelector('.nav-toggle');
  var nav = document.querySelector('.primary-nav');
  if (toggle && nav) {
    toggle.addEventListener('click', function () {
      nav.classList.toggle('is-open');
    });
  }

  var dropdownParent = document.querySelector('.has-dropdown');
  var dropdownBtn = dropdownParent ? dropdownParent.querySelector('.nav-link') : null;

  if (dropdownParent && dropdownBtn) {
    dropdownBtn.addEventListener('click', function (e) {
      e.stopPropagation();
      dropdownParent.classList.toggle('is-open');
    });
    document.addEventListener('click', function (e) {
      if (!dropdownParent.contains(e.target)) {
        dropdownParent.classList.remove('is-open');
      }
    });
  }
});
